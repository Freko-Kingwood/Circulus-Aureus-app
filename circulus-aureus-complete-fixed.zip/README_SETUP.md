Circulus Aureus – clean fixed build

Struktur:
- index.html
- app.js
- styles.css
- netlify.toml
- package.json
- assets/crest.jpeg
- netlify/functions/*.mjs

Sådan deployer du:
1. Slet alle gamle filer i dit GitHub repo.
2. Upload ALT indholdet fra denne mappe.
3. Vent på Netlify deploy.
4. Gå til Identity og slå det til.
5. Inviter din egen e-mail.
6. Log ind i appen.

Bemærk:
- ADMIN-mail er hardcoded i app.js som: frekopetersen1998@gmail.com
- Hvis du vil ændre admin senere, ret adminEmails i app.js.
